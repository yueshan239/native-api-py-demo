import iris

class Cursor(iris.irissdk.dbapiCursor): pass
